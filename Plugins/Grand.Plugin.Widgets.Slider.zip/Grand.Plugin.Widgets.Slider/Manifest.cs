﻿using Grand.Core;
using Grand.Core.Plugins;

[assembly: PluginInfo(
    FriendlyName = "Bootstrap Slider",
    Group = "Widgets",
    SystemName = "Widgets.Slider",
    SupportedVersion = GrandVersion.SupportedPluginVersion,
    Author = "grandnode team",
    Version = "1.08"
)]