﻿
namespace Grand.Plugin.Widgets.Slider.Domain
{
    public enum SliderType
    {
        HomePage = 0,
        Category = 1,
        Manufacturer = 2,
    }
}
