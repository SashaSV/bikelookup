﻿
namespace Grand.Plugin.Widgets.Slider
{
    public static class SliderDefaults
    {
        public static string WidgetZoneHomePage => "home_page_top";
        public static string WidgetZoneCategoryPage => "home_page_category";
        public static string WidgetZoneManufacturerPage => "home_page_manufacturer";

    }
}
